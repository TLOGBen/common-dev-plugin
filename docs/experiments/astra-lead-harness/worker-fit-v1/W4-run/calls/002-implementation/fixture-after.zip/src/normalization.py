from collections.abc import Mapping


def _require_list(value, name):
    if not isinstance(value, list):
        raise ValueError(f'{name} must be a list')


def _require_nonempty_string(value, name):
    if not isinstance(value, str) or not value:
        raise ValueError(f'{name} must be a non-empty string')


def _require_integer(value, name, *, positive=False):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f'{name} must be an integer')
    if positive and value <= 0:
        raise ValueError(f'{name} must be positive')
    if not positive and value < 0:
        raise ValueError(f'{name} must be non-negative')


def normalize_events(events):
    """Validate, deduplicate, and canonicalize all events.

    The returned records contain only fields that define event identity.  This
    deliberately discards extra input fields, so they cannot affect either
    conflict detection or projection.
    """
    _require_list(events, 'events')

    by_event_id = {}
    occupied_revisions = {}
    normalized = []

    for event in events:
        if not isinstance(event, Mapping):
            raise ValueError('each event must be a mapping')
        required = ('event_id', 'account_id', 'revision', 'delta')
        if any(field not in event for field in required):
            raise ValueError('event is missing a required field')

        event_id = event['event_id']
        account_id = event['account_id']
        revision = event['revision']
        delta = event['delta']
        _require_nonempty_string(event_id, 'event_id')
        _require_nonempty_string(account_id, 'account_id')
        _require_integer(revision, 'revision', positive=True)
        if isinstance(delta, bool) or not isinstance(delta, int):
            raise ValueError('delta must be an integer')

        canonical = (event_id, account_id, revision, delta)
        prior = by_event_id.get(event_id)
        if prior is not None:
            if prior != canonical:
                raise ValueError('event_id has conflicting contents')
            continue

        slot = (account_id, revision)
        if slot in occupied_revisions:
            raise ValueError('revision is occupied by different event IDs')
        by_event_id[event_id] = canonical
        occupied_revisions[slot] = event_id
        normalized.append(canonical)

    return normalized
