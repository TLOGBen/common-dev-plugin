from collections.abc import Mapping

from .normalization import normalize_events


def _require_list(value, name):
    if not isinstance(value, list):
        raise ValueError(f'{name} must be a list')


def _require_nonempty_string(value, name):
    if not isinstance(value, str) or not value:
        raise ValueError(f'{name} must be a non-empty string')


def _require_integer(value, name, *, non_negative):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f'{name} must be an integer')
    if non_negative and value < 0:
        raise ValueError(f'{name} must be non-negative')


def _validate_snapshots(snapshots):
    _require_list(snapshots, 'snapshots')
    validated = []
    seen_ids = set()
    for snapshot in snapshots:
        if not isinstance(snapshot, Mapping):
            raise ValueError('each snapshot must be a mapping')
        required = ('account_id', 'revision', 'balance')
        if any(field not in snapshot for field in required):
            raise ValueError('snapshot is missing a required field')

        account_id = snapshot['account_id']
        revision = snapshot['revision']
        balance = snapshot['balance']
        _require_nonempty_string(account_id, 'account_id')
        _require_integer(revision, 'revision', non_negative=True)
        if isinstance(balance, bool) or not isinstance(balance, int):
            raise ValueError('balance must be an integer')
        if account_id in seen_ids:
            raise ValueError('account_id is duplicated in snapshots')
        seen_ids.add(account_id)
        # Only copy scalar contract fields; the caller's mapping is untouched.
        validated.append((account_id, revision, balance))
    return validated


def _validate_requested_ids(requested_ids):
    _require_list(requested_ids, 'requested_ids')
    for account_id in requested_ids:
        _require_nonempty_string(account_id, 'requested account_id')
    return sorted(set(requested_ids))


def project_accounts(snapshots, events, requested_ids):
    # Validate every input before looking at requested_ids or projecting any
    # account.  In particular, unrequested and unknown-account events still
    # participate in validation and global conflict detection.
    validated_snapshots = _validate_snapshots(snapshots)
    normalized_events = normalize_events(events)
    requested = _validate_requested_ids(requested_ids)

    snapshots_by_id = {
        account_id: (revision, balance)
        for account_id, revision, balance in validated_snapshots
    }
    events_by_account = {}
    for event_id, account_id, revision, delta in normalized_events:
        events_by_account.setdefault(account_id, []).append((revision, delta))
    for account_events in events_by_account.values():
        account_events.sort(key=lambda item: item[0])

    accounts = []
    for account_id in requested:
        snapshot = snapshots_by_id.get(account_id)
        if snapshot is None:
            accounts.append({'account_id': account_id, 'status': 'missing',
                             'revision': None, 'balance': None,
                             'first_missing_revision': None})
            continue

        snapshot_revision, snapshot_balance = snapshot
        current_revision = snapshot_revision
        balance = snapshot_balance
        incomplete_at = None
        for revision, delta in events_by_account.get(account_id, ()):
            if revision <= snapshot_revision:
                continue
            if revision != current_revision + 1:
                incomplete_at = current_revision + 1
                break
            current_revision = revision
            balance += delta

        if incomplete_at is None:
            accounts.append({'account_id': account_id, 'status': 'complete',
                             'revision': current_revision, 'balance': balance,
                             'first_missing_revision': None})
        else:
            accounts.append({'account_id': account_id, 'status': 'incomplete',
                             'revision': current_revision, 'balance': None,
                             'first_missing_revision': incomplete_at})

    return {'accounts': accounts,
            'duplicates_ignored': len(events) - len(normalized_events)}
