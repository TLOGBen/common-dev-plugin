import copy
import unittest
from src.projector import project_accounts


class ProjectorTests(unittest.TestCase):
    def test_contiguous_delta(self):
        result = project_accounts([{'account_id': 'A', 'revision': 1, 'balance': 20}],
                                  [{'event_id': 'e2', 'account_id': 'A', 'revision': 2, 'delta': -3}], ['A'])
        self.assertEqual(result, {'accounts': [{'account_id': 'A', 'status': 'complete',
                         'revision': 2, 'balance': 17, 'first_missing_revision': None}], 'duplicates_ignored': 0})

    def test_no_snapshot(self):
        result = project_accounts([], [], ['Z'])
        self.assertEqual(result, {'accounts': [{'account_id': 'Z', 'status': 'missing',
                         'revision': None, 'balance': None, 'first_missing_revision': None}], 'duplicates_ignored': 0})

    def test_out_of_order_resends_and_extra_fields(self):
        snapshots = [{'account_id': 'A', 'revision': 4, 'balance': 10,
                      'snapshot_note': 'keep me'}]
        events = [
            {'event_id': 'e6', 'account_id': 'A', 'revision': 6, 'delta': 7,
             'trace': 'first'},
            {'event_id': 'e5', 'account_id': 'A', 'revision': 5, 'delta': -2},
            {'event_id': 'e6', 'account_id': 'A', 'revision': 6, 'delta': 7,
             'trace': 'different extra field'},
        ]
        requested_ids = ['B', 'A', 'A']
        before = copy.deepcopy((snapshots, events, requested_ids))

        result = project_accounts(snapshots, events, requested_ids)

        self.assertEqual(result, {'accounts': [
            {'account_id': 'A', 'status': 'complete', 'revision': 6,
             'balance': 15, 'first_missing_revision': None},
            {'account_id': 'B', 'status': 'missing', 'revision': None,
             'balance': None, 'first_missing_revision': None},
        ], 'duplicates_ignored': 1})
        self.assertEqual((snapshots, events, requested_ids), before)

    def test_gap_stops_before_later_event(self):
        result = project_accounts(
            [{'account_id': 'A', 'revision': 10, 'balance': 100}],
            [{'event_id': 'e13', 'account_id': 'A', 'revision': 13, 'delta': 30},
             {'event_id': 'e11', 'account_id': 'A', 'revision': 11, 'delta': 1}],
            ['A'])
        self.assertEqual(result['accounts'], [{
            'account_id': 'A', 'status': 'incomplete', 'revision': 11,
            'balance': None, 'first_missing_revision': 12,
        }])

    def test_huge_revision_gap_does_not_enumerate_missing_values(self):
        huge_revision = 10**100
        result = project_accounts(
            [{'account_id': 'A', 'revision': 0, 'balance': 3}],
            [{'event_id': 'huge', 'account_id': 'A', 'revision': huge_revision,
              'delta': 99}],
            ['A'])
        self.assertEqual(result['accounts'][0], {
            'account_id': 'A', 'status': 'incomplete', 'revision': 0,
            'balance': None, 'first_missing_revision': 1,
        })

    def test_global_conflicts_are_checked_before_account_selection(self):
        cases = [
            # The conflicting revision is historical relative to the snapshot.
            ([{'account_id': 'A', 'revision': 5, 'balance': 0}],
             [{'event_id': 'old-1', 'account_id': 'A', 'revision': 3, 'delta': 1},
              {'event_id': 'old-2', 'account_id': 'A', 'revision': 3, 'delta': 1}],
             ['A']),
            # Both events target an account with no snapshot.
            ([{'account_id': 'A', 'revision': 0, 'balance': 0}],
             [{'event_id': 'unknown-1', 'account_id': 'Z', 'revision': 1, 'delta': 1},
              {'event_id': 'unknown-2', 'account_id': 'Z', 'revision': 1, 'delta': 1}],
             ['A']),
            # B is not selected, but its event namespace is still global.
            ([{'account_id': 'A', 'revision': 0, 'balance': 0},
              {'account_id': 'B', 'revision': 0, 'balance': 0}],
             [{'event_id': 'unselected-1', 'account_id': 'B', 'revision': 1, 'delta': 1},
              {'event_id': 'unselected-2', 'account_id': 'B', 'revision': 1, 'delta': 1}],
             ['A']),
        ]
        for snapshots, events, requested_ids in cases:
            with self.subTest(events=events):
                with self.assertRaises(ValueError):
                    project_accounts(snapshots, events, requested_ids)

    def test_same_event_id_conflict_and_different_id_conflict(self):
        with self.assertRaises(ValueError):
            project_accounts([], [
                {'event_id': 'e', 'account_id': 'A', 'revision': 1, 'delta': 1},
                {'event_id': 'e', 'account_id': 'A', 'revision': 1, 'delta': 2},
            ], [])
        with self.assertRaises(ValueError):
            project_accounts([], [
                {'event_id': 'e1', 'account_id': 'A', 'revision': 1, 'delta': 1},
                {'event_id': 'e2', 'account_id': 'A', 'revision': 1, 'delta': 1},
            ], [])

    def test_validation_matrix(self):
        invalid_calls = [
            ((), [], []),
            ([], (), []),
            ([], [], ()),
            ([{'account_id': '', 'revision': 0, 'balance': 0}], [], []),
            ([{'account_id': 'A', 'revision': -1, 'balance': 0}], [], []),
            ([{'account_id': 'A', 'revision': True, 'balance': 0}], [], []),
            ([{'account_id': 'A', 'revision': 0, 'balance': False}], [], []),
            ([{'account_id': 'A', 'revision': 0}], [], []),
            ([{'account_id': 'A', 'revision': 0, 'balance': 0},
              {'account_id': 'A', 'revision': 1, 'balance': 1}], [], []),
            ([], [{'event_id': '', 'account_id': 'A', 'revision': 1, 'delta': 1}], []),
            ([], [{'event_id': 'e', 'account_id': '', 'revision': 1, 'delta': 1}], []),
            ([], [{'event_id': 'e', 'account_id': 'A', 'revision': 0, 'delta': 1}], []),
            ([], [{'event_id': 'e', 'account_id': 'A', 'revision': True, 'delta': 1}], []),
            ([], [{'event_id': 'e', 'account_id': 'A', 'revision': 1, 'delta': False}], []),
            ([], [{'event_id': 'e', 'account_id': 'A', 'revision': 1}], []),
            ([], [], ['']),
            ([], [], [1]),
        ]
        for args in invalid_calls:
            with self.subTest(args=args):
                with self.assertRaises(ValueError):
                    project_accounts(*args)

    def test_all_events_validated_even_when_no_snapshot_exists(self):
        with self.assertRaises(ValueError):
            project_accounts([], [{'event_id': 'bad', 'account_id': 'Z',
                                  'revision': True, 'delta': 1}], ['A'])

    def test_historical_events_are_ignored_after_validation(self):
        result = project_accounts(
            [{'account_id': 'A', 'revision': 4, 'balance': 20}],
            [{'event_id': 'old', 'account_id': 'A', 'revision': 2, 'delta': 100},
             {'event_id': 'new', 'account_id': 'A', 'revision': 5, 'delta': -3}],
            ['A'])
        self.assertEqual(result['accounts'][0]['balance'], 17)
        self.assertEqual(result['duplicates_ignored'], 0)

    def test_duplicate_count_is_global_not_query_scoped(self):
        result = project_accounts(
            [{'account_id': 'A', 'revision': 5, 'balance': 20}],
            [{'event_id': 'historical', 'account_id': 'A', 'revision': 2, 'delta': 1},
             {'event_id': 'historical', 'account_id': 'A', 'revision': 2, 'delta': 1},
             {'event_id': 'unknown', 'account_id': 'Z', 'revision': 1, 'delta': 4},
             {'event_id': 'unknown', 'account_id': 'Z', 'revision': 1, 'delta': 4}],
            ['A'])
        self.assertEqual(result['duplicates_ignored'], 2)
        self.assertEqual(result['accounts'][0]['status'], 'complete')


if __name__ == '__main__':
    unittest.main()
