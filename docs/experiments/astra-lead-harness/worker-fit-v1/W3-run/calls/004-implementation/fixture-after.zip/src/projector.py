from .normalization import (
    normalize_events,
    normalize_requested_ids,
    normalize_snapshots,
)


def project_accounts(snapshots, events, requested_ids):
    # Perform all input validation before constructing any query result.
    snapshot_rows = normalize_snapshots(snapshots)
    event_rows, duplicates_ignored = normalize_events(events)
    account_ids = normalize_requested_ids(requested_ids)

    snapshots_by_id = {
        account_id: (revision, balance)
        for account_id, revision, balance in snapshot_rows
    }
    events_by_account = {}
    for _event_id, account_id, revision, delta in event_rows:
        events_by_account.setdefault(account_id, []).append((revision, delta))

    accounts = []
    for account_id in account_ids:
        snapshot = snapshots_by_id.get(account_id)
        if snapshot is None:
            accounts.append({
                'account_id': account_id,
                'status': 'missing',
                'revision': None,
                'balance': None,
                'first_missing_revision': None,
            })
            continue

        snapshot_revision, snapshot_balance = snapshot
        # Conflicts and duplicate handling already happened globally. At most
        # one event remains for each account/revision, so sorting is sufficient
        # to make the result independent of arrival order.
        future_events = sorted(
            (revision, delta)
            for revision, delta in events_by_account.get(account_id, ())
            if revision > snapshot_revision
        )
        expected_revision = snapshot_revision + 1
        last_contiguous_revision = snapshot_revision
        balance = snapshot_balance
        incomplete_at = None

        for revision, delta in future_events:
            if revision != expected_revision:
                incomplete_at = expected_revision
                break
            balance += delta
            last_contiguous_revision = revision
            expected_revision += 1

        if incomplete_at is not None:
            accounts.append({
                'account_id': account_id,
                'status': 'incomplete',
                'revision': last_contiguous_revision,
                'balance': None,
                'first_missing_revision': incomplete_at,
            })
        else:
            accounts.append({
                'account_id': account_id,
                'status': 'complete',
                'revision': last_contiguous_revision,
                'balance': balance,
                'first_missing_revision': None,
            })

    return {'accounts': accounts, 'duplicates_ignored': duplicates_ignored}
