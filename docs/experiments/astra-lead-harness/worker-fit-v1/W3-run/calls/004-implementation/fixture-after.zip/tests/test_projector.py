import unittest
from src.projector import project_accounts


class ProjectorTests(unittest.TestCase):
    def test_contiguous_delta(self):
        result = project_accounts([{'account_id': 'A', 'revision': 1, 'balance': 20}],
                                  [{'event_id': 'e2', 'account_id': 'A', 'revision': 2, 'delta': -3}], ['A'])
        self.assertEqual(result, {'accounts': [{'account_id': 'A', 'status': 'complete',
                         'revision': 2, 'balance': 17, 'first_missing_revision': None}], 'duplicates_ignored': 0})

    def test_no_snapshot(self):
        result = project_accounts([], [], ['Z'])
        self.assertEqual(result, {'accounts': [{'account_id': 'Z', 'status': 'missing',
                         'revision': None, 'balance': None, 'first_missing_revision': None}], 'duplicates_ignored': 0})

    def test_reorders_events_and_ignores_history(self):
        snapshots = [
            {'account_id': 'A', 'revision': 2, 'balance': 20, 'label': 'keep'},
        ]
        events = [
            {'event_id': 'new-4', 'account_id': 'A', 'revision': 4, 'delta': -2},
            {'event_id': 'old-1', 'account_id': 'A', 'revision': 1, 'delta': 100},
            {'event_id': 'new-3', 'account_id': 'A', 'revision': 3, 'delta': 4},
        ]
        expected = {
            'accounts': [{'account_id': 'A', 'status': 'complete', 'revision': 4,
                          'balance': 22, 'first_missing_revision': None}],
            'duplicates_ignored': 0,
        }
        result = project_accounts(snapshots, events, ['A'])
        self.assertEqual(result, expected)
        self.assertEqual(project_accounts(snapshots, list(reversed(events)), ['A']), expected)

    def test_gap_after_contiguous_prefix_handles_huge_revision(self):
        revision = 10 ** 100
        result = project_accounts(
            [{'account_id': 'A', 'revision': revision, 'balance': 20}],
            [
                {'event_id': 'after-gap', 'account_id': 'A',
                 'revision': revision + 4, 'delta': 9},
                {'event_id': 'prefix-2', 'account_id': 'A',
                 'revision': revision + 2, 'delta': -3},
                {'event_id': 'prefix-1', 'account_id': 'A',
                 'revision': revision + 1, 'delta': 4},
            ],
            ['A'],
        )
        self.assertEqual(result, {
            'accounts': [{'account_id': 'A', 'status': 'incomplete',
                          'revision': revision + 2, 'balance': None,
                          'first_missing_revision': revision + 3}],
            'duplicates_ignored': 0,
        })

    def test_validation_contract_boundaries(self):
        valid_snapshot = {'account_id': 'A', 'revision': 0, 'balance': 1}
        valid_event = {'event_id': 'e1', 'account_id': 'A',
                       'revision': 1, 'delta': 1}
        list_cases = [
            ('snapshots must be list', (None, [valid_event], ['A'])),
            ('events must be list', ([valid_snapshot], None, ['A'])),
            ('requested_ids must be list', ([valid_snapshot], [], None)),
        ]
        for label, args in list_cases:
            with self.subTest(label=label):
                with self.assertRaises(ValueError):
                    project_accounts(*args)

        required_field_cases = [
            ('snapshot account_id', 'snapshots', 'account_id'),
            ('snapshot revision', 'snapshots', 'revision'),
            ('snapshot balance', 'snapshots', 'balance'),
            ('event event_id', 'events', 'event_id'),
            ('event account_id', 'events', 'account_id'),
            ('event revision', 'events', 'revision'),
            ('event delta', 'events', 'delta'),
        ]
        for label, collection, field in required_field_cases:
            with self.subTest(label=label):
                snapshot = dict(valid_snapshot)
                event = dict(valid_event)
                del (snapshot if collection == 'snapshots' else event)[field]
                with self.assertRaises(ValueError):
                    project_accounts([snapshot], [event], ['A'])

        value_cases = [
            ('empty snapshot account_id', [{'account_id': '', 'revision': 0, 'balance': 1}],
             [], ['A']),
            ('non-string snapshot account_id', [{'account_id': 7, 'revision': 0, 'balance': 1}],
             [], ['A']),
            ('empty event event_id', [valid_snapshot],
             [{'event_id': '', 'account_id': 'A', 'revision': 1, 'delta': 1}], ['A']),
            ('empty event account_id', [valid_snapshot],
             [{'event_id': 'e1', 'account_id': '', 'revision': 1, 'delta': 1}], ['A']),
            ('empty requested account_id', [valid_snapshot], [], ['']),
            ('snapshot revision below zero',
             [{'account_id': 'A', 'revision': -1, 'balance': 1}], [], ['A']),
            ('event revision zero', [valid_snapshot],
             [{'event_id': 'e1', 'account_id': 'A', 'revision': 0, 'delta': 1}], ['A']),
            ('snapshot revision bool',
             [{'account_id': 'A', 'revision': True, 'balance': 1}], [], ['A']),
            ('snapshot revision float',
             [{'account_id': 'A', 'revision': 1.0, 'balance': 1}], [], ['A']),
            ('snapshot balance bool',
             [{'account_id': 'A', 'revision': 0, 'balance': False}], [], ['A']),
            ('snapshot balance float',
             [{'account_id': 'A', 'revision': 0, 'balance': 1.0}], [], ['A']),
            ('event revision bool', [valid_snapshot],
             [{'event_id': 'e1', 'account_id': 'A', 'revision': True, 'delta': 1}], ['A']),
            ('event revision float', [valid_snapshot],
             [{'event_id': 'e1', 'account_id': 'A', 'revision': 1.0, 'delta': 1}], ['A']),
            ('event delta bool', [valid_snapshot],
             [{'event_id': 'e1', 'account_id': 'A', 'revision': 1, 'delta': True}], ['A']),
            ('event delta float', [valid_snapshot],
             [{'event_id': 'e1', 'account_id': 'A', 'revision': 1, 'delta': 1.0}], ['A']),
        ]
        for label, snapshots, events, requested_ids in value_cases:
            with self.subTest(label=label):
                with self.assertRaises(ValueError):
                    project_accounts(snapshots, events, requested_ids)

        with self.assertRaises(ValueError):
            project_accounts(
                [valid_snapshot, dict(valid_snapshot, balance=2)], [], ['A'])

    def test_conflicts_are_global_across_history_unknown_and_unqueried_data(self):
        same_event_id_conflicts = [
            ('account_id', {'event_id': 'e1', 'account_id': 'B', 'revision': 5, 'delta': 2}),
            ('revision', {'event_id': 'e1', 'account_id': 'A', 'revision': 6, 'delta': 2}),
            ('delta', {'event_id': 'e1', 'account_id': 'A', 'revision': 5, 'delta': 3}),
        ]
        for field, conflicting_event in same_event_id_conflicts:
            with self.subTest(same_event_id_field=field):
                with self.assertRaises(ValueError):
                    project_accounts(
                        [],
                        [{'event_id': 'e1', 'account_id': 'A', 'revision': 5, 'delta': 2},
                         conflicting_event],
                        [],
                    )

        slot_conflicts = [
            ('history',
             [{'account_id': 'A', 'revision': 10, 'balance': 0}],
             ['A'],
             'A'),
            ('unknown account',
             [{'account_id': 'A', 'revision': 0, 'balance': 0}],
             ['A'],
             'Z'),
            ('unqueried account',
             [{'account_id': 'A', 'revision': 0, 'balance': 0}],
             ['A'],
             'B'),
        ]
        for label, snapshots, requested_ids, account_id in slot_conflicts:
            with self.subTest(slot_context=label):
                events = [
                    {'event_id': 'first', 'account_id': account_id,
                     'revision': 1 if label != 'history' else 5, 'delta': 1},
                    {'event_id': 'second', 'account_id': account_id,
                     'revision': 1 if label != 'history' else 5, 'delta': 1},
                ]
                with self.assertRaises(ValueError):
                    project_accounts(snapshots, events, requested_ids)

    def test_resends_with_different_extras_count_for_history_and_unknown_accounts(self):
        history = {'event_id': 'history', 'account_id': 'A', 'revision': 1, 'delta': 4}
        unknown = {'event_id': 'unknown', 'account_id': 'Z', 'revision': 1, 'delta': 7}
        events = [
            dict(history, extra={'attempt': 1}),
            dict(history, extra={'attempt': 2, 'source': 'retry'}),
            dict(history, extra={'attempt': 3, 'source': 'replay'}),
            dict(unknown, extra={'attempt': 1}),
            dict(unknown, extra={'attempt': 2, 'source': 'retry'}),
        ]
        result = project_accounts(
            [{'account_id': 'A', 'revision': 2, 'balance': 20}],
            events,
            ['Z', 'A', 'Z'],
        )
        self.assertEqual(result, {
            'accounts': [
                {'account_id': 'A', 'status': 'complete', 'revision': 2,
                 'balance': 20, 'first_missing_revision': None},
                {'account_id': 'Z', 'status': 'missing', 'revision': None,
                 'balance': None, 'first_missing_revision': None},
            ],
            'duplicates_ignored': 3,
        })

    def test_gap_does_not_apply_events_after_gap(self):
        result = project_accounts(
            [{'account_id': 'A', 'revision': 10, 'balance': 20}],
            [
                {'event_id': 'later', 'account_id': 'A', 'revision': 12, 'delta': 9},
            ],
            ['A'],
        )
        self.assertEqual(result['accounts'][0], {
            'account_id': 'A', 'status': 'incomplete', 'revision': 10,
            'balance': None, 'first_missing_revision': 11,
        })

    def test_duplicate_and_conflicting_event_rules(self):
        duplicate = {
            'event_id': 'e2', 'account_id': 'A', 'revision': 2, 'delta': 3,
            'extra': {'source': 'first'},
        }
        duplicate_with_extra = dict(duplicate, extra={'source': 'second'})
        result = project_accounts(
            [{'account_id': 'A', 'revision': 1, 'balance': 20}],
            [duplicate, duplicate_with_extra],
            ['A'],
        )
        self.assertEqual(result['duplicates_ignored'], 1)
        self.assertEqual(result['accounts'][0]['balance'], 23)

        with self.assertRaises(ValueError):
            project_accounts([], [
                {'event_id': 'e1', 'account_id': 'A', 'revision': 99, 'delta': 1},
                {'event_id': 'e2', 'account_id': 'A', 'revision': 99, 'delta': 1},
            ], [])
        with self.assertRaises(ValueError):
            project_accounts([], [
                {'event_id': 'e1', 'account_id': 'A', 'revision': 1, 'delta': 1},
                {'event_id': 'e1', 'account_id': 'A', 'revision': 1, 'delta': 2},
            ], [])

    def test_requested_accounts_are_sorted_deduplicated_and_schema_limited(self):
        result = project_accounts(
            [{'account_id': 'B', 'revision': 0, 'balance': 7, 'extra': 'ignored'},
             {'account_id': 'A', 'revision': 0, 'balance': 3}],
            [],
            ['B', 'A', 'B', 'C'],
        )
        self.assertEqual(result, {
            'accounts': [
                {'account_id': 'A', 'status': 'complete', 'revision': 0,
                 'balance': 3, 'first_missing_revision': None},
                {'account_id': 'B', 'status': 'complete', 'revision': 0,
                 'balance': 7, 'first_missing_revision': None},
                {'account_id': 'C', 'status': 'missing', 'revision': None,
                 'balance': None, 'first_missing_revision': None},
            ],
            'duplicates_ignored': 0,
        })

    def test_validation_is_global_and_rejects_bool_integers(self):
        with self.assertRaises(ValueError):
            project_accounts(
                [{'account_id': 'A', 'revision': 0, 'balance': 1}],
                [{'event_id': 'bad', 'account_id': 'unknown', 'revision': True, 'delta': 1}],
                [],
            )
        with self.assertRaises(ValueError):
            project_accounts(
                [{'account_id': 'A', 'revision': 0, 'balance': 1}],
                [{'event_id': 'bad', 'account_id': 'unknown', 'revision': 1, 'delta': False}],
                [],
            )

    def test_inputs_and_nested_extra_fields_are_unchanged(self):
        snapshots = [{'account_id': 'A', 'revision': 1, 'balance': 5,
                      'meta': {'tags': ['x']}}]
        events = [{'event_id': 'e2', 'account_id': 'A', 'revision': 2,
                   'delta': 1, 'meta': {'tags': ['y']}}]
        requested_ids = ['A', 'A']
        snapshots_before = repr(snapshots)
        events_before = repr(events)
        requested_before = list(requested_ids)

        project_accounts(snapshots, events, requested_ids)

        self.assertEqual(repr(snapshots), snapshots_before)
        self.assertEqual(repr(events), events_before)
        self.assertEqual(requested_ids, requested_before)


if __name__ == '__main__':
    unittest.main()
