from collections.abc import Mapping


def _require_list(value, name):
    if not isinstance(value, list):
        raise ValueError(f'{name} must be a list')


def _require_non_empty_string(value, name):
    if not isinstance(value, str) or not value:
        raise ValueError(f'{name} must be a non-empty string')


def _require_integer(value, name, *, minimum=None):
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f'{name} must be an integer')
    if minimum is not None and value < minimum:
        raise ValueError(f'{name} is below its minimum')


def _require_mapping(row, name):
    if not isinstance(row, Mapping):
        raise ValueError(f'{name} must be a mapping')


def normalize_snapshots(snapshots):
    """Validate snapshots and return only the fields used by projection."""
    _require_list(snapshots, 'snapshots')
    normalized = []
    account_ids = set()
    for index, snapshot in enumerate(snapshots):
        row_name = f'snapshots[{index}]'
        _require_mapping(snapshot, row_name)
        for field in ('account_id', 'revision', 'balance'):
            if field not in snapshot:
                raise ValueError(f'{row_name} is missing {field}')
        account_id = snapshot['account_id']
        revision = snapshot['revision']
        balance = snapshot['balance']
        _require_non_empty_string(account_id, f'{row_name}.account_id')
        _require_integer(revision, f'{row_name}.revision', minimum=0)
        _require_integer(balance, f'{row_name}.balance')
        if account_id in account_ids:
            raise ValueError(f'duplicate snapshot account_id: {account_id}')
        account_ids.add(account_id)
        normalized.append((account_id, revision, balance))
    return normalized


def normalize_events(events):
    """Validate, detect conflicts, and deduplicate events.

    The returned tuples deliberately omit extra fields, so they cannot affect
    projection or be mutated as a side effect of processing.
    """
    _require_list(events, 'events')

    validated = []
    for index, event in enumerate(events):
        row_name = f'events[{index}]'
        _require_mapping(event, row_name)
        for field in ('event_id', 'account_id', 'revision', 'delta'):
            if field not in event:
                raise ValueError(f'{row_name} is missing {field}')
        event_id = event['event_id']
        account_id = event['account_id']
        revision = event['revision']
        delta = event['delta']
        _require_non_empty_string(event_id, f'{row_name}.event_id')
        _require_non_empty_string(account_id, f'{row_name}.account_id')
        _require_integer(revision, f'{row_name}.revision', minimum=1)
        _require_integer(delta, f'{row_name}.delta')
        validated.append((event_id, account_id, revision, delta))

    by_event_id = {}
    by_account_revision = {}
    normalized = []
    duplicates_ignored = 0
    for event_id, account_id, revision, delta in validated:
        signature = (account_id, revision, delta)
        previous = by_event_id.get(event_id)
        if previous is not None:
            if previous != signature:
                raise ValueError(f'conflicting event_id: {event_id}')
            duplicates_ignored += 1
            continue

        slot = (account_id, revision)
        occupying_event_id = by_account_revision.get(slot)
        if occupying_event_id is not None and occupying_event_id != event_id:
            raise ValueError(
                f'conflicting events at account revision: {account_id}, {revision}'
            )
        by_event_id[event_id] = signature
        by_account_revision[slot] = event_id
        normalized.append((event_id, account_id, revision, delta))

    return normalized, duplicates_ignored


def normalize_requested_ids(requested_ids):
    """Validate requested IDs and return their sorted unique values."""
    _require_list(requested_ids, 'requested_ids')
    for index, account_id in enumerate(requested_ids):
        _require_non_empty_string(account_id, f'requested_ids[{index}]')
    return sorted(set(requested_ids))
