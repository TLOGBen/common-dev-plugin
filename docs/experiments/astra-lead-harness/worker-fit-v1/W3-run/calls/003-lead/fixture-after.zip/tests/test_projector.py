import unittest
from src.projector import project_accounts


class ProjectorTests(unittest.TestCase):
    def test_contiguous_delta(self):
        result = project_accounts([{'account_id': 'A', 'revision': 1, 'balance': 20}],
                                  [{'event_id': 'e2', 'account_id': 'A', 'revision': 2, 'delta': -3}], ['A'])
        self.assertEqual(result, {'accounts': [{'account_id': 'A', 'status': 'complete',
                         'revision': 2, 'balance': 17, 'first_missing_revision': None}], 'duplicates_ignored': 0})

    def test_no_snapshot(self):
        result = project_accounts([], [], ['Z'])
        self.assertEqual(result, {'accounts': [{'account_id': 'Z', 'status': 'missing',
                         'revision': None, 'balance': None, 'first_missing_revision': None}], 'duplicates_ignored': 0})

    def test_reorders_events_and_ignores_history(self):
        result = project_accounts(
            [{'account_id': 'A', 'revision': 2, 'balance': 20, 'label': 'keep'}],
            [
                {'event_id': 'new-3', 'account_id': 'A', 'revision': 3, 'delta': 4},
                {'event_id': 'old-1', 'account_id': 'A', 'revision': 1, 'delta': 100},
                {'event_id': 'new-4', 'account_id': 'A', 'revision': 4, 'delta': -2},
            ],
            ['A'],
        )
        self.assertEqual(result['accounts'][0]['revision'], 4)
        self.assertEqual(result['accounts'][0]['balance'], 22)
        self.assertEqual(result['accounts'][0]['status'], 'complete')

    def test_gap_does_not_apply_events_after_gap(self):
        result = project_accounts(
            [{'account_id': 'A', 'revision': 10, 'balance': 20}],
            [
                {'event_id': 'later', 'account_id': 'A', 'revision': 12, 'delta': 9},
            ],
            ['A'],
        )
        self.assertEqual(result['accounts'][0], {
            'account_id': 'A', 'status': 'incomplete', 'revision': 10,
            'balance': None, 'first_missing_revision': 11,
        })

    def test_duplicate_and_conflicting_event_rules(self):
        duplicate = {
            'event_id': 'e2', 'account_id': 'A', 'revision': 2, 'delta': 3,
            'extra': {'source': 'first'},
        }
        duplicate_with_extra = dict(duplicate, extra={'source': 'second'})
        result = project_accounts(
            [{'account_id': 'A', 'revision': 1, 'balance': 20}],
            [duplicate, duplicate_with_extra],
            ['A'],
        )
        self.assertEqual(result['duplicates_ignored'], 1)
        self.assertEqual(result['accounts'][0]['balance'], 23)

        with self.assertRaises(ValueError):
            project_accounts([], [
                {'event_id': 'e1', 'account_id': 'A', 'revision': 99, 'delta': 1},
                {'event_id': 'e2', 'account_id': 'A', 'revision': 99, 'delta': 1},
            ], [])
        with self.assertRaises(ValueError):
            project_accounts([], [
                {'event_id': 'e1', 'account_id': 'A', 'revision': 1, 'delta': 1},
                {'event_id': 'e1', 'account_id': 'A', 'revision': 1, 'delta': 2},
            ], [])

    def test_requested_accounts_are_sorted_deduplicated_and_schema_limited(self):
        result = project_accounts(
            [{'account_id': 'B', 'revision': 0, 'balance': 7, 'extra': 'ignored'},
             {'account_id': 'A', 'revision': 0, 'balance': 3}],
            [],
            ['B', 'A', 'B', 'C'],
        )
        self.assertEqual(result, {
            'accounts': [
                {'account_id': 'A', 'status': 'complete', 'revision': 0,
                 'balance': 3, 'first_missing_revision': None},
                {'account_id': 'B', 'status': 'complete', 'revision': 0,
                 'balance': 7, 'first_missing_revision': None},
                {'account_id': 'C', 'status': 'missing', 'revision': None,
                 'balance': None, 'first_missing_revision': None},
            ],
            'duplicates_ignored': 0,
        })

    def test_validation_is_global_and_rejects_bool_integers(self):
        with self.assertRaises(ValueError):
            project_accounts(
                [{'account_id': 'A', 'revision': 0, 'balance': 1}],
                [{'event_id': 'bad', 'account_id': 'unknown', 'revision': True, 'delta': 1}],
                [],
            )
        with self.assertRaises(ValueError):
            project_accounts(
                [{'account_id': 'A', 'revision': 0, 'balance': 1}],
                [{'event_id': 'bad', 'account_id': 'unknown', 'revision': 1, 'delta': False}],
                [],
            )

    def test_inputs_and_nested_extra_fields_are_unchanged(self):
        snapshots = [{'account_id': 'A', 'revision': 1, 'balance': 5,
                      'meta': {'tags': ['x']}}]
        events = [{'event_id': 'e2', 'account_id': 'A', 'revision': 2,
                   'delta': 1, 'meta': {'tags': ['y']}}]
        requested_ids = ['A', 'A']
        snapshots_before = repr(snapshots)
        events_before = repr(events)
        requested_before = list(requested_ids)

        project_accounts(snapshots, events, requested_ids)

        self.assertEqual(repr(snapshots), snapshots_before)
        self.assertEqual(repr(events), events_before)
        self.assertEqual(requested_ids, requested_before)


if __name__ == '__main__':
    unittest.main()
