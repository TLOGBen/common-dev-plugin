import test from "node:test";
import assert from "node:assert/strict";
import { countLabel } from "../src/count-label.mjs";

test("zero records", () => {
  assert.equal(countLabel(0), "0 records");
});

test("one record", () => {
  assert.equal(countLabel(1), "1 record");
});

test("multiple records", () => {
  assert.equal(countLabel(2), "2 records");
});
