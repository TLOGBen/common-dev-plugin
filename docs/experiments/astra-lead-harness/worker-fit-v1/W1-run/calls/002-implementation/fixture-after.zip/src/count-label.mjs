export function countLabel(count) {
  return count === 1 ? "1 record" : `${count} records`;
}
