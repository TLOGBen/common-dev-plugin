本文件為合成測試附件的高值估算預覽，未經 PM 核准。已完成本地資料核對與估算文件製作；下列施工與驗收皆為待執行的工作說明，並非實際系統已完成的結果。

高值合計 **13 人天：開發 7.5、測試 5.5**。附件只提供高值單位人天，低值與基準為未提供，不能視為零、不能由高值反推。人天表示投入量，不代表日曆工期、排程或金額。

本預覽依使用者已固定的合成範圍與費率整理：共用設定／執行底座、全量 API 共同轉換、三項例外增量及整合驗證。既有畫面維持不變；客戶負責正式 UAT，我方整合驗證仍納入。附件未提供業務流程名稱、目標版本、實際原始碼、產碼設定路徑或驗收案例內容，不補造這些資訊。

**數量與去重核對**

| 證據 | 核對結果 | 計價角色與邊界 |
|---|---|---|
| inventory.csv | 87 列、87 個唯一 canonical ID、87 個唯一來源路徑；84 個 normal＋3 個 exception；87 列 batch_included 皆為 true | 全量修改範圍證據；共同轉換只計 1 批，包含三項例外的一般部分 |
| aliases.csv | 3 筆唯一別名路徑，皆指向已存在的例外 canonical ID | 別名新增 canonical 數為 0；87 個來源與 3 個別名共 90 筆路徑記錄仍對應 87 個工作對象 |
| generated.json | 宣告 generated 輸出 136、人工修改單位 0；pricedWithin 為 shared-foundation | 來源設定調整後整批重生與驗證，含於共用底座；136 不乘人工單價 |
| coverage.csv | 13 個唯一 coverage ID，全數 priced_within 為 integration-verification | 僅覆蓋證據；整合驗證計 1 包，不逐筆收費 |
| unchanged-and-responsibility.json | 既有畫面無須異動；正式 UAT owner 為 customer | 畫面追加 0 人天，客戶正式 UAT 的供應方追加 0 人天；不扣除我方整合測試 |

數量守恆：87＝84＋3；三項例外已在 87 之內，不能再把共同轉換擴成 90。API、產碼輸出、覆蓋條目屬不同集合，不將 87＋136＋13 合併成計價單位。generated 的 136 為附件宣告值，未取得逐檔清冊或執行重生，故只驗證宣告與歸屬一致，沒有獨立證明輸出存在或可重現。coverage 有完整 ID 清單，但沒有實際測試結果。

**工作分解與高值公式**

每個工作 ID 恰好歸入下表的一個成果包；對外 CSV 依此順序彙總相同工作。所有費率直接來自 rates.json 的 developmentPerUnit／testPerUnit，沒有重新校準或拆造步驟單價。

| CSV 序號／成果包 | 工作 ID／樣態 | 計價數量 | 每單位開發／測試 | 高值開發／測試 | 合計 |
|---|---|---:|---:|---:|---:|
| 1／共用執行與產製能力 | shared-foundation／共用一次 | 1 | 4／1 | 4／1 | 5 |
| 2／既有介面共同轉換 | homogeneous-batch／批次 | 1 | 2／1 | 2／1 | 3 |
| 3／上傳、簽章資料與交易特殊處理 | exception-increment／例外增量 | 3 | 0.5／0.5 | 1.5／1.5 | 3 |
| 4／介面整合驗證 | integration-verification／整合驗證 | 1 | 0／2 | 0／2 | 2 |
| 總計 | 四項工作唯一歸屬 | — | — | 7.5／5.5 | 13 |

開發＝1×4＋1×2＋3×0.5＋1×0＝7.5；測試＝1×1＋1×1＋3×0.5＋1×2＝5.5。全數保留半日粒度，無額外比例緩衝、無新增費率。

**PM 可轉述的施工與驗收說明**

以下為依附件 covers／method 整理的承作說明與建議驗收證據；尚無實際實作切片或工時實績支持費率校準，也沒有把說明中的步驟各自配置新的人天。責任依附件供應方工作／客戶 UAT 的邊界整理，未指定實際人員。

1. **共用執行與產製能力｜開發 4、測試 1。** 為讓共同轉換有一致的設定與執行基礎，開發調整一套共用底座及產製來源設定，再重生 136 個輸出；測試核對重生結果。共用能力只做一次，輸出不逐檔計人工。建議以固定來源／設定、重生操作及結果核對紀錄作為完成證據；具體來源檔案未提供。這筆測試只承接底座與重生核對，跨介面覆蓋另由整合包承接。

2. **既有介面共同轉換｜開發 2、測試 1。** 為使全量介面接受同一套共同轉換，開發先整理共同改法，再整批套用 87 個 canonical API；測試核對清冊守恆及共同處理結果。一般代表落點為 api-001（src/api/Api001.java），僅為附件代表項，未檢視實際程式。完成證據應含 87 項處理對照與共同規則驗證；三項例外的一般部分已包含，特殊部分由下一包承接。

3. **上傳、簽章資料與交易特殊處理｜開發 1.5、測試 1.5。** 共同規則以外尚有三個已識別的例外。開發針對 api-085 的 upload、api-086 的 signed-payload、api-087 的 transaction 各補做特殊調整與除錯，每項開發 0.5；測試各驗證特殊處理，每項測試 0.5。建議完成證據為三份對應例外行為的案例與結果，僅承接超出共同批次的增量，不重收一般轉換。附件未定義上傳限制、簽章演算法或交易成功／失敗契約，具體斷言需由責任人補定。

4. **介面整合驗證｜開發 0、測試 2。** 為確認調整後的串接結果，測試彙整 13 個既定覆蓋條目、執行一包整合檢查並記錄問題與結果。每筆 coverage 對應同一包驗證，沒有 13 次獨立計價；附件未配置此包開發人天，不能補加開發費率。完成證據應為 13 個 ID 全數對應的測試結果及問題處置紀錄；此處不把測試核對宣稱為額外開發修復承諾。正式 UAT 仍由客戶負責。

施工依賴為共用底座 → 共同批次 → 例外增量 → 整合驗證，最後銜接客戶正式 UAT；這是工作依賴說明，並非已承諾的排程。一般／特殊局部檢查與跨介面整合檢查目的不同，驗證紀錄應標示所屬工作以避免重複歸價。

**唯一 canonical 工作集合**

下表直接投影 inventory.csv，以原有 canonical ID 作為穩定識別；87 項均納入 homogeneous-batch，並均屬修改範圍證據。例外欄只標出額外歸入 exception-increment 的特殊操作，同一 API 的一般與特殊操作互斥。來源路徑僅為附件記錄，沒有宣稱這些 Java 檔案存在於本工作目錄。

| canonical ID | 附件來源路徑 | 分類／例外 | 別名（新增數量 0） |
|---|---|---|---|
| api-001 | src/api/Api001.java | 一般 | — |
| api-002 | src/api/Api002.java | 一般 | — |
| api-003 | src/api/Api003.java | 一般 | — |
| api-004 | src/api/Api004.java | 一般 | — |
| api-005 | src/api/Api005.java | 一般 | — |
| api-006 | src/api/Api006.java | 一般 | — |
| api-007 | src/api/Api007.java | 一般 | — |
| api-008 | src/api/Api008.java | 一般 | — |
| api-009 | src/api/Api009.java | 一般 | — |
| api-010 | src/api/Api010.java | 一般 | — |
| api-011 | src/api/Api011.java | 一般 | — |
| api-012 | src/api/Api012.java | 一般 | — |
| api-013 | src/api/Api013.java | 一般 | — |
| api-014 | src/api/Api014.java | 一般 | — |
| api-015 | src/api/Api015.java | 一般 | — |
| api-016 | src/api/Api016.java | 一般 | — |
| api-017 | src/api/Api017.java | 一般 | — |
| api-018 | src/api/Api018.java | 一般 | — |
| api-019 | src/api/Api019.java | 一般 | — |
| api-020 | src/api/Api020.java | 一般 | — |
| api-021 | src/api/Api021.java | 一般 | — |
| api-022 | src/api/Api022.java | 一般 | — |
| api-023 | src/api/Api023.java | 一般 | — |
| api-024 | src/api/Api024.java | 一般 | — |
| api-025 | src/api/Api025.java | 一般 | — |
| api-026 | src/api/Api026.java | 一般 | — |
| api-027 | src/api/Api027.java | 一般 | — |
| api-028 | src/api/Api028.java | 一般 | — |
| api-029 | src/api/Api029.java | 一般 | — |
| api-030 | src/api/Api030.java | 一般 | — |
| api-031 | src/api/Api031.java | 一般 | — |
| api-032 | src/api/Api032.java | 一般 | — |
| api-033 | src/api/Api033.java | 一般 | — |
| api-034 | src/api/Api034.java | 一般 | — |
| api-035 | src/api/Api035.java | 一般 | — |
| api-036 | src/api/Api036.java | 一般 | — |
| api-037 | src/api/Api037.java | 一般 | — |
| api-038 | src/api/Api038.java | 一般 | — |
| api-039 | src/api/Api039.java | 一般 | — |
| api-040 | src/api/Api040.java | 一般 | — |
| api-041 | src/api/Api041.java | 一般 | — |
| api-042 | src/api/Api042.java | 一般 | — |
| api-043 | src/api/Api043.java | 一般 | — |
| api-044 | src/api/Api044.java | 一般 | — |
| api-045 | src/api/Api045.java | 一般 | — |
| api-046 | src/api/Api046.java | 一般 | — |
| api-047 | src/api/Api047.java | 一般 | — |
| api-048 | src/api/Api048.java | 一般 | — |
| api-049 | src/api/Api049.java | 一般 | — |
| api-050 | src/api/Api050.java | 一般 | — |
| api-051 | src/api/Api051.java | 一般 | — |
| api-052 | src/api/Api052.java | 一般 | — |
| api-053 | src/api/Api053.java | 一般 | — |
| api-054 | src/api/Api054.java | 一般 | — |
| api-055 | src/api/Api055.java | 一般 | — |
| api-056 | src/api/Api056.java | 一般 | — |
| api-057 | src/api/Api057.java | 一般 | — |
| api-058 | src/api/Api058.java | 一般 | — |
| api-059 | src/api/Api059.java | 一般 | — |
| api-060 | src/api/Api060.java | 一般 | — |
| api-061 | src/api/Api061.java | 一般 | — |
| api-062 | src/api/Api062.java | 一般 | — |
| api-063 | src/api/Api063.java | 一般 | — |
| api-064 | src/api/Api064.java | 一般 | — |
| api-065 | src/api/Api065.java | 一般 | — |
| api-066 | src/api/Api066.java | 一般 | — |
| api-067 | src/api/Api067.java | 一般 | — |
| api-068 | src/api/Api068.java | 一般 | — |
| api-069 | src/api/Api069.java | 一般 | — |
| api-070 | src/api/Api070.java | 一般 | — |
| api-071 | src/api/Api071.java | 一般 | — |
| api-072 | src/api/Api072.java | 一般 | — |
| api-073 | src/api/Api073.java | 一般 | — |
| api-074 | src/api/Api074.java | 一般 | — |
| api-075 | src/api/Api075.java | 一般 | — |
| api-076 | src/api/Api076.java | 一般 | — |
| api-077 | src/api/Api077.java | 一般 | — |
| api-078 | src/api/Api078.java | 一般 | — |
| api-079 | src/api/Api079.java | 一般 | — |
| api-080 | src/api/Api080.java | 一般 | — |
| api-081 | src/api/Api081.java | 一般 | — |
| api-082 | src/api/Api082.java | 一般 | — |
| api-083 | src/api/Api083.java | 一般 | — |
| api-084 | src/api/Api084.java | 一般 | — |
| api-085 | src/api/Api085.java | upload | inventory-export/UploadApi.java |
| api-086 | src/api/Api086.java | signed-payload | inventory-export/SignedApi.java |
| api-087 | src/api/Api087.java | transaction | inventory-export/TransactionApi.java |

**整合覆蓋集合**

全數僅作範圍證據；不捏造條目名稱、案例內容或通過結果。

| coverage ID | 唯一計價歸屬 |
|---|---|
| integration-01 | integration-verification |
| integration-02 | integration-verification |
| integration-03 | integration-verification |
| integration-04 | integration-verification |
| integration-05 | integration-verification |
| integration-06 | integration-verification |
| integration-07 | integration-verification |
| integration-08 | integration-verification |
| integration-09 | integration-verification |
| integration-10 | integration-verification |
| integration-11 | integration-verification |
| integration-12 | integration-verification |
| integration-13 | integration-verification |

**檢查結論與限制**

已用 Python 標準函式庫讀取六份附件，核對 canonical 唯一性、來源路徑唯一性、完整 ID 集合、分類守恆、batch_included、別名指向、generated 歸屬、coverage 唯一性與歸屬、零人天責任及高值算術。逐項檢查了「別名另算」「例外重收共同工作」「generated 逐輸出計價」「coverage 逐條計價」「漏掉供應方整合測試」等替代計數方式，附件均支持上述去重結果。未發現需要更改固定範圍或人天的附件矛盾。

這些結果證明合成附件的一致性與計價可重算；無實際原始碼、建置環境、測試輸出或業務操作證據，不能推出相容性成立、系統驗收通過、工時實績成立或真實商業交付完成。

本地交付僅包含 estimate-external.csv、assessment-report.md、handoff.md。直接由同次讀取的附件與高值工作模型生成，CSV 為 UTF-8 BOM、標準五欄、數字序號及單段功能說明。依使用者指定範圍，不初始化完整 case 或 assessment-state.json，不執行完整 generator，也不建立低值／基準、HTML、Excel 或其他檔案；無 render／開啟瀏覽器操作。

對外 CSV 已回讀核對欄位、順序、逐列與總計人天，並以實際主表檢視範圍、主要動作、計價原因與完成結果。這是本地文字檢視；未進行獨立讀者或真人 PM 回述，亦未記錄任何 PM 核准。

人工作業：本次預覽製作無須追加決策。PM 可據此說明高值範圍，是否接受估算仍由 PM 決定；若要推進實際施工，由供應方與客戶補定具體環境、行為契約、13 項覆蓋案例及驗收證據要求，客戶另承接正式 UAT。這些是後續成果的成立條件，並非本預覽未完成的檔案工作。
