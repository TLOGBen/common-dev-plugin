# 合成固定範圍高值估算預覽

本預覽依六份本地合成附件整理，供 PM 說明必要工作、施工方式、計價原因與驗收方式。高值為開發 **7.5 人天**、測試 **5.5 人天**，合計 **13 人天**。這是投入工作量，不是工期或金額。費率全取自 `rates.json`，未補造低值、基準值、歷史校準或 PM 核准。

使用者已固定預覽範圍與高值費率；本文件不代表正式估算核准、商務報價或實際施工完成。以下「施工／驗收」描述待執行工作的完成條件；實際完成的本地工作僅為附件讀取、資料核對、計算及三份預覽產物。

## 數量與計價邊界

| 集合／證據 | 核對數量 | 工作分類與歸屬 | 真正計價乘數 |
|---|---:|---|---:|
| canonical API | 87＝84 一般＋3 例外 | direct-touch；全部納入共同轉換，完整清單見附錄 | 共同轉換 1 批 |
| 例外子集 | 3 | api-085 上傳、api-086 簽署資料、api-087 交易；僅計超出共同轉換的增量 | 3 個例外 |
| 別名 | 3 | 已對應上述例外 canonical ID；只是另一個名稱 | 0 個新增 API |
| generated 輸出 | 136 | generated；從變更後來源設定重產及核對，含於共用底座 | 0 個人工逐件單位 |
| coverage | 13 | evidence-only；全部歸入整合驗證 | 整合驗證 1 包 |
| 共用設定／執行底座 | 1 組 | shared；包含重產能力及其驗證 | 1 組 |

API 守恆為 **87 總數＝87 需處理＋0 不處理＋0 未知**；全部 `batch_included=true`。這個零未知僅限附件列出的 API 分類與歸屬，不能延伸為實際程式或執行環境已無未知。84＋3 是同一集合的互斥分類；三個例外已在 87 個共同轉換範圍中，增量不再收取完整一般工作。

別名與 canonical 合看是 90 筆來源／別名紀錄，去重後仍是 87 個 API。136 個 generated 輸出和 13 筆 coverage 屬不同集合，不能加到 API 數或作額外逐件乘數。generated 的輸出數是附件宣告，未提供逐檔清單，未實際重產核實 136 個檔案。

## 高值工作分解與公式

單位為人天；單位費率與每列乘積各向上取至 0.5 人天，開發與測試分開計算。附件費率及本次乘積已是 0.5 的倍數，取整不增加數值。四個工作各自唯一對應 CSV 一列，成果包直接加總所屬工作，沒有另一套手填總數。

| CSV 序號／工作 ID | 乘數 | 開發單位高值 | 測試單位高值 | 開發公式 | 測試公式 | 合計 |
|---|---:|---:|---:|---|---|---:|
| 1／`shared-foundation` | 1 | 4 | 1 | 1 × 4＝4 | 1 × 1＝1 | 5 |
| 2／`homogeneous-batch` | 1 | 2 | 1 | 1 × 2＝2 | 1 × 1＝1 | 3 |
| 3／`exception-increment` | 3 | 0.5 | 0.5 | 3 × 0.5＝1.5 | 3 × 0.5＝1.5 | 3 |
| 4／`integration-verification` | 1 | 0 | 2 | 1 × 0＝0 | 1 × 2＝2 | 2 |
| 合計 | — | — | — | 7.5 | 5.5 | 13 |

開發：4＋2＋3×0.5＋0＝7.5；測試：1＋1＋3×0.5＋2＝5.5。低值／基準值的來源欄位 `lowAndBaselineRates=null`，因此保留為未提供；不把高值複製成另外兩區間，也不以比例推算。合成費率是本次指定輸入，沒有實測切片或歷史案件校準證據。

## 工作方法與 PM 說明

### 1. 共用執行設定與可重現產製｜開發 4／測試 1

**為什麼需要：** 共同轉換需有一致的設定與執行底座，產製輸出也必須能隨來源設定重建；否則只改 API 不能說明衍生輸出是否一致。此必要性依附件所定工作範圍解釋，未宣稱已發現某個版本不相容。

**怎麼做與計價：** 調整共用設定與執行底座，依變更後來源設定重新產製，再核對結果。開發 4 人天承接一組共用調整及可重現重產；測試 1 人天承接底座與重產結果核對。136 個輸出含在此工作中，人工逐件修改乘數為零，不另列重產費用。

**怎麼驗收：** 應能保存來源設定、重產操作與結果核對紀錄，重複產製所得內容符合預期；比對輸出數量及必要差異，136 是待核實的附件宣告數。此處是底座與產製驗證，跨功能 coverage 歸第 4 包。

**落點與證據限制：** `rates.json` 的 `shared-foundation` 與 `generated.json` 指定了來源設定、方法及歸屬，但沒有來源設定檔名、產碼器版本、重產命令或輸出逐名清單。保留此限制，不捏造路徑；工程實作前需定位來源與重產入口。

### 2. 既有服務介面共同轉換｜開發 2／測試 1

**為什麼需要：** 固定範圍中的 87 個 API 都標記要納入共同轉換，需確保相同規則一致套用且沒有漏列。84 個一般 API 及 3 個例外的一般部分共同承接於此。

**怎麼做與計價：** 依 canonical 清單整理共同規則、整批套用至來源檔，再對帳全部處理結果。開發 2 人天對應同規則的一批施工及核對，測試 1 人天對應共同轉換驗證；87 是範圍證據，不能乘上批次單價。代表一般落點為 `api-001`／`src/api/Api001.java`，其餘逐名列於附錄。

**怎麼驗收：** 87 個 canonical ID 均有唯一處理對應，清單不遺漏、不重複；共同規則的轉換檢查符合預期。三個例外的一般部分仍須包含於本批，特殊行為另依第 3 包驗收。重產由第 1 包承接，整合覆蓋由第 4 包承接。

**落點與證據限制：** API 及來源路徑以 `inventory.csv` 為準。本地只有清冊，未附這些 Java 原始碼或具體轉換規則；方法是依合成範圍形成的施工分解，並非已檢查程式後確認的改碼結果。

### 3. 上傳、簽署資料與交易特殊處理｜開發 1.5／測試 1.5

**為什麼需要：** 附件明列三種超出共同批次的特殊行為，需要各自補足調整與驗證。若只做共同規則，這些行為缺乏獨立的完成證據。

**怎麼做與計價：** 對 `api-085` 的上傳、`api-086` 的簽署資料及 `api-087` 的交易，分別釐清特殊契約、補足一般轉換未涵蓋的處理、執行例外驗證。每個例外只增加開發 0.5／測試 0.5，三項合計開發 1.5／測試 1.5；同一 API 的一般工作已包含在第 2 包。

**怎麼驗收：** 每種例外各有特殊行為測試與預期／實際結果。可依既有契約設計上傳成功與失敗、簽署資料有效與無效、交易成功與回復等檢查；這些是供實作採用的驗收設計方向，具體條件未由附件提供，不能宣稱已執行或已通過。

**別名去重及逐項增量：**

| canonical ID | 正式來源路徑 | 別名路徑（不新增單位） | 例外 | 開發增量 | 測試增量 |
| api-085 | `src/api/Api085.java` | `inventory-export/UploadApi.java` | upload | 0.5 | 0.5 |
| api-086 | `src/api/Api086.java` | `inventory-export/SignedApi.java` | signed-payload | 0.5 | 0.5 |
| api-087 | `src/api/Api087.java` | `inventory-export/TransactionApi.java` | transaction | 0.5 | 0.5 |

三筆 `aliases.csv` 均以「same canonical work item」說明關係，且 canonical ID 存在於清冊；本地完成的是映射完整性核對，未以程式內容比對別名檔案是否相同。

### 4. 跨功能整合驗證｜開發 0／測試 2

**為什麼需要：** 共同規則、產製及例外局部驗證，還需要由供應方的一包整合測試確認跨功能結果。客戶負責正式 UAT，不會取消供應方此項驗證責任。

**怎麼做與計價：** 將 13 筆 coverage 對應整合檢查，準備預期結果、執行驗證並保存紀錄。附件明定一包測試 2 人天、開發 0 人天，13 筆是包內覆蓋清單，不是 13 包或 13 次單價。未另外加入開發修復或未約定保障費用。

**怎麼驗收：** 13 筆 coverage 各有可追溯的案例、預期結果與執行結果，整合檢查符合預期且可交接。coverage 附件只有 ID 與歸屬，尚無案例內容及執行結果；本次只核對 ID 唯一性與計價歸屬，不能宣稱整合測試已通過。

| coverage ID | 唯一承接工作 |
| integration-01 | `integration-verification` |
| integration-02 | `integration-verification` |
| integration-03 | `integration-verification` |
| integration-04 | `integration-verification` |
| integration-05 | `integration-verification` |
| integration-06 | `integration-verification` |
| integration-07 | `integration-verification` |
| integration-08 | `integration-verification` |
| integration-09 | `integration-verification` |
| integration-10 | `integration-verification` |
| integration-11 | `integration-verification` |
| integration-12 | `integration-verification` |
| integration-13 | `integration-verification` |

## 零增量與責任

| 項目 | 本次新增人天 | 責任與邊界 |
|---|---:|---|
| 既有畫面不異動 | 0 | `unchanged-and-responsibility.json` 明定不需變更；未提供畫面數或名稱，不虛構清單，也不推論為零個畫面。 |
| 客戶正式 UAT | 供應方增量 0 | owner 為 customer；客戶承接正式驗收，不表示客戶本身投入為零；供應方整合驗證 2 人天仍在範圍內。 |

共用能力及重產 → 87 個 API 共同轉換 → 3 個特殊行為增量 → 一包 13 項整合覆蓋，構成可說明的成果與工作關係。正式 UAT 由客戶另行承接。這是工作依賴的說明，沒有推算排程或承諾部署。

## 本地核對結果與證據界線

- 已讀取並解析六份附件；canonical ID 87 個唯一、來源路徑 87 個唯一，84 一般／3 例外分類守恆，全部納入同批。
- 已核對 3 個別名均指向已存在的例外 ID，別名路徑唯一且未冒充新增 canonical 項目。
- 已核對 generated 的 136 輸出／0 人工單位及 `shared-foundation` 歸屬；未實際執行產碼。
- 已核對 13 個 coverage ID 唯一且全歸 `integration-verification`；未實際執行整合測試。
- 已核對四項費率數量為 1／1／3／1，開發測試各自取整、逐列乘算及加總，並回讀 CSV 驗證五欄、純數字、序號與合計。
- 三份預覽由同次記憶體中的附件資料與計算結果寫出；未建立正式 case、低／基準估算、HTML、Excel 或 generator 狀態，也未使用正式 generator 以免補造其必要欄位。沒有渲染或開啟瀏覽器。
- 僅以主 Agent 回讀實際 CSV 逐列檢視範圍、主要動作、費用驅動與完成結果；未委派另一位讀者，不宣稱已有獨立讀者或 PM 驗收。

來源定位：`inventory.csv` 以 canonical ID 查找；`aliases.csv` 以 canonical ID／alias_path 查找；`coverage.csv` 以 coverage_id 查找；`generated.json` 以 generatedOutputCount、manualChangeUnits、method、pricedWithin 查找；`rates.json` 以 items[].id 及 lowAndBaselineRates 查找；`unchanged-and-responsibility.json` 以 unchangedScope 與 customerFormalUAT 查找。來源均位於本報告上層目錄。

## 尚待成果與人員承接

本次高值預覽已可交付，沒有需要使用者補資料才能完成預覽的停等。若要採用為實際施工依據，工程人員須取得真正來源與轉換規則、產碼入口及輸出清單、特殊行為契約、13 項整合案例及測試環境，完成施工和執行證據；PM 須自行審閱範圍、人天及責任，決定是否核准或提出調整，客戶承接正式 UAT。這些實際成果與人類承諾均未由本地附件核對代為完成。

## 附錄：唯一 canonical 工作集合

以下直接投影 `inventory.csv` 的完整 87 筆 stable ID 與來源路徑，不另建立估價用平行清單。全部屬 direct-touch、`batch_included=true`，作為共同批次範圍證據；只有標示例外的三筆另帶特殊工作增量。頁面不在異動範圍；未提供 API URL，保留 canonical ID 而不補造端點。

| canonical ID | 附件宣告的來源路徑 | 類型 | 共同批次 | 例外增量 |
| api-001 | `src/api/Api001.java` | normal | 納入 | 無 |
| api-002 | `src/api/Api002.java` | normal | 納入 | 無 |
| api-003 | `src/api/Api003.java` | normal | 納入 | 無 |
| api-004 | `src/api/Api004.java` | normal | 納入 | 無 |
| api-005 | `src/api/Api005.java` | normal | 納入 | 無 |
| api-006 | `src/api/Api006.java` | normal | 納入 | 無 |
| api-007 | `src/api/Api007.java` | normal | 納入 | 無 |
| api-008 | `src/api/Api008.java` | normal | 納入 | 無 |
| api-009 | `src/api/Api009.java` | normal | 納入 | 無 |
| api-010 | `src/api/Api010.java` | normal | 納入 | 無 |
| api-011 | `src/api/Api011.java` | normal | 納入 | 無 |
| api-012 | `src/api/Api012.java` | normal | 納入 | 無 |
| api-013 | `src/api/Api013.java` | normal | 納入 | 無 |
| api-014 | `src/api/Api014.java` | normal | 納入 | 無 |
| api-015 | `src/api/Api015.java` | normal | 納入 | 無 |
| api-016 | `src/api/Api016.java` | normal | 納入 | 無 |
| api-017 | `src/api/Api017.java` | normal | 納入 | 無 |
| api-018 | `src/api/Api018.java` | normal | 納入 | 無 |
| api-019 | `src/api/Api019.java` | normal | 納入 | 無 |
| api-020 | `src/api/Api020.java` | normal | 納入 | 無 |
| api-021 | `src/api/Api021.java` | normal | 納入 | 無 |
| api-022 | `src/api/Api022.java` | normal | 納入 | 無 |
| api-023 | `src/api/Api023.java` | normal | 納入 | 無 |
| api-024 | `src/api/Api024.java` | normal | 納入 | 無 |
| api-025 | `src/api/Api025.java` | normal | 納入 | 無 |
| api-026 | `src/api/Api026.java` | normal | 納入 | 無 |
| api-027 | `src/api/Api027.java` | normal | 納入 | 無 |
| api-028 | `src/api/Api028.java` | normal | 納入 | 無 |
| api-029 | `src/api/Api029.java` | normal | 納入 | 無 |
| api-030 | `src/api/Api030.java` | normal | 納入 | 無 |
| api-031 | `src/api/Api031.java` | normal | 納入 | 無 |
| api-032 | `src/api/Api032.java` | normal | 納入 | 無 |
| api-033 | `src/api/Api033.java` | normal | 納入 | 無 |
| api-034 | `src/api/Api034.java` | normal | 納入 | 無 |
| api-035 | `src/api/Api035.java` | normal | 納入 | 無 |
| api-036 | `src/api/Api036.java` | normal | 納入 | 無 |
| api-037 | `src/api/Api037.java` | normal | 納入 | 無 |
| api-038 | `src/api/Api038.java` | normal | 納入 | 無 |
| api-039 | `src/api/Api039.java` | normal | 納入 | 無 |
| api-040 | `src/api/Api040.java` | normal | 納入 | 無 |
| api-041 | `src/api/Api041.java` | normal | 納入 | 無 |
| api-042 | `src/api/Api042.java` | normal | 納入 | 無 |
| api-043 | `src/api/Api043.java` | normal | 納入 | 無 |
| api-044 | `src/api/Api044.java` | normal | 納入 | 無 |
| api-045 | `src/api/Api045.java` | normal | 納入 | 無 |
| api-046 | `src/api/Api046.java` | normal | 納入 | 無 |
| api-047 | `src/api/Api047.java` | normal | 納入 | 無 |
| api-048 | `src/api/Api048.java` | normal | 納入 | 無 |
| api-049 | `src/api/Api049.java` | normal | 納入 | 無 |
| api-050 | `src/api/Api050.java` | normal | 納入 | 無 |
| api-051 | `src/api/Api051.java` | normal | 納入 | 無 |
| api-052 | `src/api/Api052.java` | normal | 納入 | 無 |
| api-053 | `src/api/Api053.java` | normal | 納入 | 無 |
| api-054 | `src/api/Api054.java` | normal | 納入 | 無 |
| api-055 | `src/api/Api055.java` | normal | 納入 | 無 |
| api-056 | `src/api/Api056.java` | normal | 納入 | 無 |
| api-057 | `src/api/Api057.java` | normal | 納入 | 無 |
| api-058 | `src/api/Api058.java` | normal | 納入 | 無 |
| api-059 | `src/api/Api059.java` | normal | 納入 | 無 |
| api-060 | `src/api/Api060.java` | normal | 納入 | 無 |
| api-061 | `src/api/Api061.java` | normal | 納入 | 無 |
| api-062 | `src/api/Api062.java` | normal | 納入 | 無 |
| api-063 | `src/api/Api063.java` | normal | 納入 | 無 |
| api-064 | `src/api/Api064.java` | normal | 納入 | 無 |
| api-065 | `src/api/Api065.java` | normal | 納入 | 無 |
| api-066 | `src/api/Api066.java` | normal | 納入 | 無 |
| api-067 | `src/api/Api067.java` | normal | 納入 | 無 |
| api-068 | `src/api/Api068.java` | normal | 納入 | 無 |
| api-069 | `src/api/Api069.java` | normal | 納入 | 無 |
| api-070 | `src/api/Api070.java` | normal | 納入 | 無 |
| api-071 | `src/api/Api071.java` | normal | 納入 | 無 |
| api-072 | `src/api/Api072.java` | normal | 納入 | 無 |
| api-073 | `src/api/Api073.java` | normal | 納入 | 無 |
| api-074 | `src/api/Api074.java` | normal | 納入 | 無 |
| api-075 | `src/api/Api075.java` | normal | 納入 | 無 |
| api-076 | `src/api/Api076.java` | normal | 納入 | 無 |
| api-077 | `src/api/Api077.java` | normal | 納入 | 無 |
| api-078 | `src/api/Api078.java` | normal | 納入 | 無 |
| api-079 | `src/api/Api079.java` | normal | 納入 | 無 |
| api-080 | `src/api/Api080.java` | normal | 納入 | 無 |
| api-081 | `src/api/Api081.java` | normal | 納入 | 無 |
| api-082 | `src/api/Api082.java` | normal | 納入 | 無 |
| api-083 | `src/api/Api083.java` | normal | 納入 | 無 |
| api-084 | `src/api/Api084.java` | normal | 納入 | 無 |
| api-085 | `src/api/Api085.java` | exception | 納入 | upload |
| api-086 | `src/api/Api086.java` | exception | 納入 | signed-payload |
| api-087 | `src/api/Api087.java` | exception | 納入 | transaction |
