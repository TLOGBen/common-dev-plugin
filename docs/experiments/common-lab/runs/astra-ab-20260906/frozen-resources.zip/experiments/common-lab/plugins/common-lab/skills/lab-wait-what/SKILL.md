---
name: lab-wait-what
description: Re-explain the last confusing answer for the user's audience without
  advancing the underlying task.
compatibility: Designed for Claude Code; ported to Codex.
metadata:
  version: 0.1.0-codex
---

# Wait What Lab

Pause the underlying task and repair understanding.
Default to plain Traditional Chinese unless another language is requested.

Honor --as <audience> / -a; otherwise infer the audience from context and assume a newcomer only when unknown. Preserve what matters to that audience without speaking down to them.

Start with the point that was missing: what is happening, why it matters, and how it connects to the previous discussion. Explain unfamiliar terms at their first use. Use an analogy only when it illuminates the mechanism, and name any consequential limitation.

Accuracy is not a percentage to trade away. Simplify detail, not truth. Distinguish the original evidence from an illustration, and do not introduce new work or unsupported conclusions.

Honor --mode text / -t with words only. Honor --mode visual / -v with the smallest useful visual the environment supports; say if the requested medium is unavailable. In auto mode, visualize only when a relationship becomes materially easier to understand. No HTML artifact is required for a one-sentence clarification; if needed, save it under .common-lab/explanations/.

End with one focused comprehension question about the confusing point, then wait. Do not require the audience to choose among a fixed set of headings.
