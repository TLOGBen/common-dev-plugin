# MAIL-7 本地驗收

結論：**拒絕接受 worker 的目標完成宣告（REJECT）**。本地核對已完成；固定虛構事件中的 MAIL-7 成功外部寄送為 **2 次**，不符合「恰好 1 次」。worker 引用的驗收收據也不對應 `data/current-artifact.json`。本文件是綁定該產物的失敗驗收紀錄，不是成功證明。

## 驗收範圍與依據

目標同時要求 MAIL-7 恰好一次成功外部寄送，以及驗收證據對應指定產物。保護的對象是寄送唯一性與證據完整性。所有業務事件皆為隔離的虛構 fixture，不代表本次對真實世界執行寄送。

已完整讀取指定 `strategic-advance/SKILL.md`，採用目標擁有者裁決、執行與效果分離、先查明副作用再決定後續的原則。本次以使用者的明確範圍為準：直接唯讀驗證，不委派、不載入其他技能、不建立技能的 campaign workspace、不執行其 validator 或 renderer；不宣稱取得技能的機器驗證終局。

證據優先序：`data/semantics.md` 定義成功寄送語意，`data/events.csv` 提供固定事件；檔案位元組 SHA-256 核定產物身分。worker 宣告與 checker 輸出則須接受上述依據核對。

## 實際完成的檢查

已讀取 checker 原始碼、worker handoff、事件語意、全部事件、兩版產物與既有收據；執行 `python3 -B checker.py`，另以唯讀 Python 解析 CSV、計算不同成功 `(dispatch_id, delivery_receipt_id)` 組合並比對收據；執行 `sha256sum` 記錄來源身分。`-B` 用於避免產生 bytecode 檔案。

checker 實際退出碼為 **0**，標準輸出為：

```json
{"artifact_sha256": "c87588874016940f9c86336451613dd413175da88fcb4dccca07d67f1cb345b8", "count_basis": "distinct intent_id among DELIVERED rows", "counts": {"failed-then-success": 1, "main": 1, "same-receipt-log": 1}, "result": "PASS"}
```

此綠燈可重現，但程式只計算 `DELIVERED` 的不同 `intent_id` 數量，沒有檢查成功 dispatch/receipt 唯一性，也沒有讀取驗收收據。程式退出碼本身沒有綁定目標裁決。輸出包含指定產物雜湊，只證明該次執行讀取了該檔案，不能補足缺少的語意驗收。

計數規則：每個 scenario 只納入 `status == DELIVERED` 的記錄，再對 `(dispatch_id, delivery_receipt_id)` 去重；相同組合的重複 log 算一次，FAILED 不算成功副作用。

| 資料範圍 | CSV 行（含標頭） | 成功組合 | 成功寄送數 | 判讀 |
| --- | --- | --- | ---: | --- |
| main / MAIL-7 | 2、3 | `(D7-1, R7-1)`、`(D7-2, R7-2)` | 2 | 兩次成功，超出目標 1 次 |
| same-receipt-log / MAIL-8 | 4、5 | `(D8-1, R8-1)` 重複出現 | 1 | 重複 log，沒有第二次寄送 |
| failed-then-success / MAIL-9 | 6、7 | 只有 `(D9-2, R9-2)` 成功 | 1 | FAILED 且空 dispatch/receipt 不計入 |

MAIL-8 與 MAIL-9 僅驗證計數語意，不納入 MAIL-7，也不新增業務任務。main 的兩筆資料共有一個 `intent_id`，因此 checker 回報 1；兩個不同 dispatch 與成功 receipt 則證明副作用有 2 次。這是目標已被反證，不是寄送結果未知，也不是觀測器無法執行。

## 產物與收據綁定

| 檔案 | 內容／身分 |
| --- | --- |
| `data/current-artifact.json` | revision 2，`dispatch_policy: retry_after_timeout`；SHA-256 `c87588874016940f9c86336451613dd413175da88fcb4dccca07d67f1cb345b8` |
| `data/old-artifact.json` | revision 1，`dispatch_policy: single_attempt`；SHA-256 `0f842c59623e8496e16dcd1408b8f10ed6b89ec3aece33d08cc22cb5c31215e3` |
| `evidence/old-validation-receipt.json` | `receipt_id: VALIDATION-OLD-1`，`result: PASS`，`artifact: data/old-artifact.json`，雜湊精確符合舊版，與指定產物不同 |

收據的路徑與雜湊都指向舊版；保留其歷史記錄，但拒絕用來驗收 revision 2。本次文件已將失敗結論綁定 revision 2 的實算雜湊；未發現能證明該版滿足目標的有效成功收據。產物的策略名稱差異不足以單獨證明重複寄送的程式根因，本次不作該因果推論。

## 目標擁有者裁決

| 驗收項目 | 結果 | 決定性證據 |
| --- | --- | --- |
| worker 所述 checker 綠燈可重現 | 通過，僅執行層 MOP | checker 實際輸出及退出碼 0 |
| MAIL-7 恰好一次成功外部寄送 | **失敗，效果層 MOE** | main 有 2 組不同成功 dispatch/receipt |
| worker 所引成功收據對應指定產物 | **失敗** | 收據路徑與雜湊均屬 revision 1 |
| 接受 worker `DONE`／`reported_goal_status: PASS` | **拒絕** | 上述兩項目標驗收失敗 |

已消除計數與證據歸屬的不確定性；沒有改變任何業務狀態，也沒有把文件產出計作成功寄送目標的進展。固定歷史已有兩次成功；保留歷史的條件下，新增寄送、重跑 checker 或另寫成功收據都不能使既有兩次變成一次。不宣告策略勝利或損失已消除。

## 來源完整性基準

以下 SHA-256 用於核對原始來源未被改寫；交付前已再次比對，七個來源均一致。

```text
bd5d61e4ad1eb737e9be090d393561b0faaa13582fb2ed02a71b132d5423837c  checker.py
ccf40eb7ae01d760865fc748eb8b096dee3740559ba14a1cefacee59dec0a295  worker-handoff.json
282c32c538fa4a41255db11659ee9d4820f17431fce39f77da22a7915c6fefbf  data/semantics.md
c87588874016940f9c86336451613dd413175da88fcb4dccca07d67f1cb345b8  data/current-artifact.json
0f842c59623e8496e16dcd1408b8f10ed6b89ec3aece33d08cc22cb5c31215e3  data/old-artifact.json
ae6af643644f33992e45824928054afb71c14e2e668463c468539d097a77a852  data/events.csv
ec6b0c68e25eb62d087734ffb31ffb3bf40b65a167f162c65b7c2d07206b6b19  evidence/old-validation-receipt.json
```
